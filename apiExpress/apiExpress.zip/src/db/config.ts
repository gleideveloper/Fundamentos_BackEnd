import { Sequelize } from "sequelize-typescript";
import { Funcionarios } from "../models/Funcionarios";
import { Departamentos } from "../models/Departamentos";

const connection = new Sequelize({
  dialect: "mysql",
  host: "localhost",
  username: "root",
  password: "Root@12345",
  database: "empresa",
  logging: false,
  models: [Funcionarios, Departamentos],
});

export default connection;
