import { Router } from "express";
import { Request, Response } from "express";
import { Funcionarios } from "../models/Funcionarios";
import { Departamentos } from "../models/Departamentos";

const funcionariosRouter: Router = Router();
const departamentosRouter: Router = Router();

funcionariosRouter.get("/funcionarios", async (req: Request, res: Response): Promise<Response> => {
  const funcionarios: Funcionarios[] = await Funcionarios.findAll();
  return res.status(200).json(funcionarios);
});

departamentosRouter.get(
  "/departamentos",
  async (req: Request, res: Response): Promise<Response> => {
    const departamentos: Departamentos[] = await Departamentos.findAll();
    return res.status(200).json(departamentos);
  }
);

export { funcionariosRouter, departamentosRouter };
